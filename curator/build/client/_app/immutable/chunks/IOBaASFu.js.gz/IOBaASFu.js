var oe=Object.defineProperty;var Bt=n=>{throw TypeError(n)};var re=(n,t,e)=>t in n?oe(n,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):n[t]=e;var R=(n,t,e)=>re(n,typeof t!="symbol"?t+"":t,e),Xt=(n,t,e)=>t.has(n)||Bt("Cannot "+e);var M=(n,t,e)=>(Xt(n,t,"read from private field"),e?e.call(n):t.get(n)),nt=(n,t,e)=>t.has(n)?Bt("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(n):t.set(n,e);var Ft=(n,t,e)=>(Xt(n,t,"access private method"),e);import{c as b,a as d,p as Ht,f as w,d as C,s as it}from"./D6MYdS9h.js";import{f,b as wt,g as h,e as ct,h as A,p as P,a as N,c as v,A as q,r as u,t as J,y as Q,aP as Z,n as ne,s as L,N as ae,O as se}from"./CqKpht16.js";import{C as ie,x as U,o as Wt,U as Gt,u as ce,p as de,v as Jt,z as Tt,f as at,y as ft,h as le,i as Mt,j as ue,k as xt,r as ve,V as pe,c as fe}from"./ZeYipwfv.js";import{l as $,s as I,p as m,i as F,r as Ot,c as st}from"./cli-iPJS.js";import{I as tt,s as et,P as Vt,E as he,d as ge,f as Yt,n as ht,g as me,h as be,j as Kt,F as _e,k as ye,A as ke,l as we,T as jt,m as Te,e as Qt,i as Zt,N as Pe,b as Ne,o as xe}from"./HfSINFkk.js";import"./CB1YDqdC.js";import{i as $t}from"./Yh8spgc9.js";import{d as Et}from"./DbixsQ4F.js";import{b as Pt}from"./iduMi8zz.js";function Oe(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M12 5v14"}],["path",{d:"m19 12-7 7-7-7"}]];tt(n,I({name:"arrow-down"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function te(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"m12 19-7-7 7-7"}],["path",{d:"M19 12H5"}]];tt(n,I({name:"arrow-left"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function Ee(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M5 12h14"}],["path",{d:"m12 5 7 7-7 7"}]];tt(n,I({name:"arrow-right"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function Ae(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"m5 12 7-7 7 7"}],["path",{d:"M12 19V5"}]];tt(n,I({name:"arrow-up"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function Ie(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["polyline",{points:"22 12 16 12 14 15 10 15 8 12 2 12"}],["path",{d:"M5.45 5.11 2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"}]];tt(n,I({name:"inbox"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function De(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M12 16v-4"}],["path",{d:"M12 8h.01"}]];tt(n,I({name:"info"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function ze(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2"}],["path",{d:"M9 3v18"}]];tt(n,I({name:"panel-left"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function Re(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["line",{x1:"21",x2:"14",y1:"4",y2:"4"}],["line",{x1:"10",x2:"3",y1:"4",y2:"4"}],["line",{x1:"21",x2:"12",y1:"12",y2:"12"}],["line",{x1:"8",x2:"3",y1:"12",y2:"12"}],["line",{x1:"21",x2:"16",y1:"20",y2:"20"}],["line",{x1:"12",x2:"3",y1:"20",y2:"20"}],["line",{x1:"14",x2:"14",y1:"2",y2:"6"}],["line",{x1:"8",x2:"8",y1:"10",y2:"14"}],["line",{x1:"16",x2:"16",y1:"18",y2:"22"}]];tt(n,I({name:"sliders-horizontal"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}function Me(n,t){const e=$(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.516.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2022 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2022.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 */const o=[["path",{d:"M3 6h18"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"}]];tt(n,I({name:"trash"},()=>e,{get iconNode(){return o},children:(r,i)=>{var a=b(),s=f(a);et(s,t,"default",{}),d(r,a)},$$slots:{default:!0}}))}const It=de({component:"popover",parts:["root","trigger","content","close","overlay"]}),Lt=new ie("Popover.Root");var gt,mt,bt;const Ct=class Ct{constructor(t){R(this,"opts");nt(this,gt,wt(null));R(this,"contentPresence");nt(this,mt,wt(null));nt(this,bt,wt(null));R(this,"overlayPresence");this.opts=t,this.contentPresence=new Vt({ref:U(()=>this.contentNode),open:this.opts.open,onComplete:()=>{this.opts.onOpenChangeComplete.current(this.opts.open.current)}}),this.overlayPresence=new Vt({ref:U(()=>this.overlayNode),open:this.opts.open})}static create(t){return Lt.set(new Ct(t))}get contentNode(){return h(M(this,gt))}set contentNode(t){ct(M(this,gt),t,!0)}get triggerNode(){return h(M(this,mt))}set triggerNode(t){ct(M(this,mt),t,!0)}get overlayNode(){return h(M(this,bt))}set overlayNode(t){ct(M(this,bt),t,!0)}toggleOpen(){this.opts.open.current=!this.opts.open.current}handleClose(){this.opts.open.current&&(this.opts.open.current=!1)}};gt=new WeakMap,mt=new WeakMap,bt=new WeakMap;let Dt=Ct;var Nt,ee,_t;const Ut=class Ut{constructor(t,e){nt(this,Nt);R(this,"opts");R(this,"root");R(this,"attachment");nt(this,_t,A(()=>({id:this.opts.id.current,"aria-haspopup":"dialog","aria-expanded":ce(this.root.opts.open.current),"data-state":Gt(this.root.opts.open.current),"aria-controls":Ft(this,Nt,ee).call(this),[It.trigger]:"",disabled:this.opts.disabled.current,onkeydown:this.onkeydown,onclick:this.onclick,...this.attachment})));this.opts=t,this.root=e,this.attachment=Wt(this.opts.ref,o=>this.root.triggerNode=o),this.onclick=this.onclick.bind(this),this.onkeydown=this.onkeydown.bind(this)}static create(t){return new Ut(t,Lt.get())}onclick(t){this.opts.disabled.current||t.button===0&&this.root.toggleOpen()}onkeydown(t){this.opts.disabled.current||(t.key===he||t.key===ge)&&(t.preventDefault(),this.root.toggleOpen())}get props(){return h(M(this,_t))}set props(t){ct(M(this,_t),t)}};Nt=new WeakSet,ee=function(){var t,e;if(this.root.opts.open.current&&((t=this.root.contentNode)!=null&&t.id))return(e=this.root.contentNode)==null?void 0:e.id},_t=new WeakMap;let zt=Ut;var yt,kt;const St=class St{constructor(t,e){R(this,"opts");R(this,"root");R(this,"attachment");R(this,"onInteractOutside",t=>{if(this.opts.onInteractOutside.current(t),t.defaultPrevented||!Yt(t.target))return;const e=t.target.closest(It.selector("trigger"));if(!(e&&e===this.root.triggerNode)){if(this.opts.customAnchor.current){if(Yt(this.opts.customAnchor.current)){if(this.opts.customAnchor.current.contains(t.target))return}else if(typeof this.opts.customAnchor.current=="string"){const o=document.querySelector(this.opts.customAnchor.current);if(o&&o.contains(t.target))return}}this.root.handleClose()}});R(this,"onEscapeKeydown",t=>{this.opts.onEscapeKeydown.current(t),!t.defaultPrevented&&this.root.handleClose()});nt(this,yt,A(()=>({open:this.root.opts.open.current})));nt(this,kt,A(()=>({id:this.opts.id.current,tabindex:-1,"data-state":Gt(this.root.opts.open.current),[It.content]:"",style:{pointerEvents:"auto"},...this.attachment})));R(this,"popperProps",{onInteractOutside:this.onInteractOutside,onEscapeKeydown:this.onEscapeKeydown});this.opts=t,this.root=e,this.attachment=Wt(this.opts.ref,o=>this.root.contentNode=o)}static create(t){return new St(t,Lt.get())}get shouldRender(){return this.root.contentPresence.shouldRender}get snippetProps(){return h(M(this,yt))}set snippetProps(t){ct(M(this,yt),t)}get props(){return h(M(this,kt))}set props(t){ct(M(this,kt),t)}};yt=new WeakMap,kt=new WeakMap;let Rt=St;var Le=w("<div><div><!></div></div>"),Ce=w("<div><div><!></div></div>");function Ue(n,t){const e=Ht();P(t,!0);let o=m(t,"ref",15,null),r=m(t,"id",19,()=>Jt(e)),i=m(t,"forceMount",3,!1),a=m(t,"onCloseAutoFocus",3,ht),s=m(t,"onEscapeKeydown",3,ht),l=m(t,"onInteractOutside",3,ht),p=m(t,"trapFocus",3,!0),_=m(t,"preventScroll",3,!1),y=m(t,"customAnchor",3,null),k=Ot(t,["$$slots","$$events","$$legacy","child","children","ref","id","forceMount","onCloseAutoFocus","onEscapeKeydown","onInteractOutside","trapFocus","preventScroll","customAnchor"]);const c=Rt.create({id:U(()=>r()),ref:U(()=>o(),V=>o(V)),onInteractOutside:U(()=>l()),onEscapeKeydown:U(()=>s()),customAnchor:U(()=>y())}),g=A(()=>Tt(k,c.props));var D=b(),T=f(D);{var O=V=>{me(V,I(()=>h(g),()=>c.popperProps,{get ref(){return c.opts.ref},get enabled(){return c.root.opts.open.current},get id(){return r()},get trapFocus(){return p()},get preventScroll(){return _()},loop:!0,forceMount:!0,get customAnchor(){return y()},get onCloseAutoFocus(){return a()},get shouldRender(){return c.shouldRender},popper:(W,Y)=>{let G=()=>Y==null?void 0:Y().props,vt=()=>Y==null?void 0:Y().wrapperProps;const ot=A(()=>Tt(G(),{style:Kt("popover")}));var B=b(),dt=f(B);{var lt=E=>{var x=b(),z=f(x);{let X=A(()=>({props:h(ot),wrapperProps:vt(),...c.snippetProps}));at(z,()=>t.child,()=>h(X))}d(E,x)},ut=E=>{var x=Le();ft(x,()=>({...vt()}));var z=v(x);ft(z,()=>({...h(ot)}));var X=v(z);at(X,()=>t.children??q),u(z),u(x),d(E,x)};F(dt,E=>{t.child?E(lt):E(ut,!1)})}d(W,B)},$$slots:{popper:!0}}))},H=V=>{var S=b(),W=f(S);{var Y=G=>{be(G,I(()=>h(g),()=>c.popperProps,{get ref(){return c.opts.ref},get open(){return c.root.opts.open.current},get id(){return r()},get trapFocus(){return p()},get preventScroll(){return _()},loop:!0,forceMount:!1,get customAnchor(){return y()},get onCloseAutoFocus(){return a()},get shouldRender(){return c.shouldRender},popper:(ot,B)=>{let dt=()=>B==null?void 0:B().props,lt=()=>B==null?void 0:B().wrapperProps;const ut=A(()=>Tt(dt(),{style:Kt("popover")}));var E=b(),x=f(E);{var z=rt=>{var K=b(),j=f(K);{let pt=A(()=>({props:h(ut),wrapperProps:lt(),...c.snippetProps}));at(j,()=>t.child,()=>h(pt))}d(rt,K)},X=rt=>{var K=Ce();ft(K,()=>({...lt()}));var j=v(K);ft(j,()=>({...h(ut)}));var pt=v(j);at(pt,()=>t.children??q),u(j),u(K),d(rt,K)};F(x,rt=>{t.child?rt(z):rt(X,!1)})}d(ot,E)},$$slots:{popper:!0}}))};F(W,G=>{i()||G(Y)},!0)}d(V,S)};F(T,V=>{i()?V(O):V(H,!1)})}d(n,D),N()}var Se=w("<button><!></button>");function Be(n,t){const e=Ht();P(t,!0);let o=m(t,"id",19,()=>Jt(e)),r=m(t,"ref",15,null),i=m(t,"type",3,"button"),a=m(t,"disabled",3,!1),s=Ot(t,["$$slots","$$events","$$legacy","children","child","id","ref","type","disabled"]);const l=zt.create({id:U(()=>o()),ref:U(()=>r(),_=>r(_)),disabled:U(()=>!!a())}),p=A(()=>Tt(s,l.props,{type:i()}));_e(n,{get id(){return o()},get ref(){return l.opts.ref},children:(_,y)=>{var k=b(),c=f(k);{var g=T=>{var O=b(),H=f(O);at(H,()=>t.child,()=>({props:h(p)})),d(T,O)},D=T=>{var O=Se();ft(O,()=>({...h(p)}));var H=v(O);at(H,()=>t.children??q),u(O),d(T,O)};F(c,T=>{t.child?T(g):T(D,!1)})}d(_,k)},$$slots:{default:!0}}),N()}function Xe(n,t){P(t,!0);let e=m(t,"open",15,!1),o=m(t,"onOpenChange",3,ht),r=m(t,"onOpenChangeComplete",3,ht);Dt.create({open:U(()=>e(),i=>{e(i),o()(i)}),onOpenChangeComplete:U(()=>r())}),ye(n,{children:(i,a)=>{var s=b(),l=f(s);at(l,()=>t.children??q),d(i,s)},$$slots:{default:!0}}),N()}var Fe=w('<div><div class="flex flex-wrap items-center justify-start gap-x-2"><!></div></div>');function ko(n,t){P(t,!0);let e=m(t,"class",3,"");var o=Fe(),r=v(o),i=v(r);at(i,()=>t.children),u(r),u(o),J(a=>ue(o,1,a),[()=>le(Mt("menu bg-base-200 border-base-200 md:min-h-15 w-full border-b md:px-4",e()))]),d(n,o),N()}const qt=(n,t=q,e=q,o=q)=>{var r=Ve(),i=v(r);i.__click=()=>{o()()};var a=v(i);st(a,e,(s,l)=>{l(s,{size:18})}),u(i),u(r),J(()=>xt(r,"data-tip",t())),d(n,r)};var Ve=w('<div class="tooltip tooltip-bottom z-30"><button class="btn btn-ghost flex items-center gap-x-2"><!></button></div>');function wo(n,t){P(t,!0);function e(s){switch(s.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}s.shiftKey&&s.key==="A"&&t.archive()}Q(()=>{document.addEventListener("keydown",e),Z(()=>{document.removeEventListener("keydown",e)})});var o=b(),r=f(o);{var i=s=>{qt(s,()=>"Archive",()=>ke,()=>t.archive)},a=s=>{var l=b(),p=f(l);{var _=k=>{qt(k,()=>"Un-Archive",()=>we,()=>t.unarchive)},y=k=>{var c=b(),g=f(c);{var D=T=>{};F(g,T=>{t.noteStatus==="deleted"&&T(D)},!0)}d(k,c)};F(p,k=>{t.noteStatus==="archived"?k(_):k(y,!1)},!0)}d(s,l)};F(r,s=>{t.noteStatus==="active"?s(i):s(a,!1)})}d(n,o),N()}C(["click"]);var Ye=w('<button class="btn btn-outline hover:btn-neutral border-base-300 flex items-center transition-colors duration-200"><!> <div class="hidden md:block">Back</div></button>');function To(n,t){P(t,!1);function e(i){switch(i.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}switch(i.key){case"Backspace":window.history.back();break}}Q(()=>{document.addEventListener("keydown",e),Z(()=>{document.removeEventListener("keydown",e)})}),$t();var o=Ye();o.__click=()=>window.history.back();var r=v(o);te(r,{size:15}),ne(2),u(o),d(n,o),N()}C(["click"]);const At=(n,t=q,e=q,o=q)=>{var r=Ke(),i=v(r);i.__click=()=>o()();var a=v(i);st(a,e,(s,l)=>{l(s,{size:18})}),u(i),u(r),J(()=>xt(r,"data-tip",t())),d(n,r)};var Ke=w('<div class="tooltip tooltip-bottom z-30"><button class="btn btn-ghost"><!></button></div>'),je=w("<!> <!>",1);function Po(n,t){P(t,!0);let e=m(t,"isOpen",15),o=m(t,"isPermaDeleteNoteOpen",15);function r(p){switch(p.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}p.key==="Delete"&&e(!0)}Q(()=>{document.addEventListener("keydown",r),Z(()=>{document.removeEventListener("keydown",r)})});var i=b(),a=f(i);{var s=p=>{At(p,()=>"Delete",()=>jt,()=>()=>e(!0))},l=p=>{var _=b(),y=f(_);{var k=c=>{var g=je(),D=f(g);At(D,()=>"Delete Forever",()=>jt,()=>()=>o(!0));var T=L(D,2);At(T,()=>"Restore",()=>Ie,()=>t.restore),d(c,g)};F(y,c=>{t.noteStatus==="deleted"&&c(k)},!0)}d(p,_)};F(a,p=>{t.noteStatus==="active"||t.noteStatus==="archived"?p(s):p(l,!1)})}d(n,i),N()}C(["click"]);var qe=w('<div class="tooltip tooltip-bottom z-30" data-tip="Empty Trash"><button class="btn btn-ghost"><!></button></div>');function No(n,t){P(t,!0);let e=m(t,"isOpen",15);var o=qe(),r=v(o);r.__click=()=>e(!0);var i=v(r);Me(i,{size:18}),u(r),u(o),d(n,o),N()}C(["click"]);function He(n,t){P(t,!0);let e=m(t,"ref",15,null),o=m(t,"sideOffset",3,4),r=m(t,"align",3,"center"),i=Ot(t,["$$slots","$$events","$$legacy","ref","class","sideOffset","align","portalProps"]);var a=b(),s=f(a);st(s,()=>Te,(l,p)=>{p(l,I(()=>t.portalProps,{children:(_,y)=>{var k=b(),c=f(k);{let g=A(()=>Mt("bg-base-100 border-base-content/20 text-base-content data-[state=closed]:motion-opacity-out-0 data-[state=open]:motion-opacity-in-0 data-[state=closed]:motion-scale-out-95 motion-duration-75 data-[state=open]:motion-scale-in-95 data-[side=bottom]:slide-in-from-top-2 data-[side=left]:slide-in-from-right-2 data-[side=right]:slide-in-from-left-2 data-[side=top]:slide-in-from-bottom-2 origin-(--bits-popover-content-transform-origin) outline-hidden font-display z-50 w-72 rounded-md border p-4 text-sm shadow-md",t.class));st(c,()=>Ue,(D,T)=>{T(D,I({"data-slot":"popover-content",get sideOffset(){return o()},get align(){return r()},get class(){return h(g)}},()=>i,{get ref(){return e()},set ref(O){e(O)}}))})}d(_,k)},$$slots:{default:!0}}))}),d(n,a),N()}function We(n,t){P(t,!0);let e=m(t,"ref",15,null),o=Ot(t,["$$slots","$$events","$$legacy","ref","class"]);var r=b(),i=f(r);{let a=A(()=>Mt("",t.class));st(i,()=>Be,(s,l)=>{l(s,I({"data-slot":"popover-trigger",get class(){return h(a)}},()=>o,{get ref(){return e()},set ref(p){e(p)}}))})}d(n,r),N()}const Ge=Xe;var Je=w('<div class="btn btn-ghost"><!></div>'),Qe=w('<div>Source</div> <div class="col-span-2"> </div> <div>URL</div> <div class="col-span-2 break-all"><a class="link line-clamp-2"> </a></div>',1),Ze=w('<div class="text-nowrap">Size</div> <div> </div>',1),$e=w('<div class="gap-golden-md grid grid-cols-3"><div>Last Opened</div> <div class="col-span-2"> </div> <div>Created</div> <div class="col-span-2"> </div> <div>Modified</div> <div class="col-span-2"> </div> <!> <!></div>'),to=w("<!> <!>",1);function xo(n,t){P(t,!0);const e=A(()=>t.note.last_opened?Et(t.note.last_opened).format("MMM DD YYYY, hh:ss a"):"Never"),o=A(()=>Et(t.note.added).format("MMM DD YYYY, hh:ss a")),r=A(()=>Et(t.note.updated).format("MMM DD YYYY, hh:ss a")),i=A(()=>{var y;const p=(y=t.note.resources)==null?void 0:y.reduce((k,c)=>k+c.size,0);return p?(p/1048576).toFixed(2):null});function a(p){const _=p.currentTarget;p.preventDefault(),window.open(_.href)}var s=b(),l=f(s);st(l,()=>Ge,(p,_)=>{_(p,{children:(y,k)=>{var c=to(),g=f(c);st(g,()=>We,(T,O)=>{O(T,{children:(H,V)=>{var S=Je(),W=v(S);De(W,{size:18}),u(S),d(H,S)},$$slots:{default:!0}})});var D=L(g,2);st(D,()=>He,(T,O)=>{O(T,{children:(H,V)=>{var S=$e(),W=L(v(S),2),Y=v(W,!0);u(W);var G=L(W,4),vt=v(G,!0);u(G);var ot=L(G,4),B=v(ot,!0);u(ot);var dt=L(ot,2);Qt(dt,17,()=>t.note.sources,Zt,(E,x)=>{var z=Qe(),X=L(f(z),2),rt=v(X,!0);u(X);var K=L(X,4),j=v(K);j.__click=a;var pt=v(j,!0);u(j),u(K),J(()=>{it(rt,h(x).source),xt(j,"href",h(x).source_url),it(pt,h(x).source_url)}),d(E,z)});var lt=L(dt,2);{var ut=E=>{var x=Ze(),z=L(f(x),2),X=v(z);u(z),J(()=>it(X,`${h(i)??""} MB`)),d(E,x)};F(lt,E=>{h(i)&&E(ut)})}u(S),J(()=>{it(Y,h(e)),it(vt,h(o)),it(B,h(r))}),d(H,S)},$$slots:{default:!0}})}),d(y,c)},$$slots:{default:!0}})}),d(n,s),N()}C(["click"]);var eo=w('<div class="tooltip tooltip-bottom z-30" data-tip="Change Notebook"><button class="btn btn-ghost flex items-center gap-x-2"><!> <span class="hidden md:inline"> </span></button></div>');function Oo(n,t){P(t,!0);let e=m(t,"isOpen",15);function o(p){switch(p.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}switch(p.key){case"n":p.preventDefault(),e(!0);break}}Q(()=>{document.addEventListener("keydown",o),Z(()=>{document.removeEventListener("keydown",o)})});var r=eo(),i=v(r);i.__click=()=>e(!0);var a=v(i);Pe(a,{class:"md:hidden",size:18});var s=L(a,2),l=v(s,!0);u(s),u(i),u(r),J(()=>it(l,t.notebook.name)),d(n,r),N()}C(["click"]);var oo=w('<div class="tooltip tooltip-bottom z-30" data-tip="Edit Tags"><button class="btn btn-ghost flex items-center gap-x-2"><!></button></div>');function Eo(n,t){P(t,!0);let e=m(t,"isOpen",15);function o(s){switch(s.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}switch(s.key){case"t":s.preventDefault(),e(!0);break}}Q(()=>{document.addEventListener("keydown",o),Z(()=>{document.removeEventListener("keydown",o)})});var r=oo(),i=v(r);i.__click=()=>e(!0);var a=v(i);Ne(a,{size:18}),u(i),u(r),d(n,r),N()}C(["click"]);var ro=w('<input type="radio" name="ratings" class="mask mask-star-2 bg-orange-400"/>'),no=w('<div class="rating rating-xs"></div>');function Ao(n,t){P(t,!0);let e=wt(0);function o(a){ct(e,a==t.rating?0:a,!0),t.action(h(e))}function r(a){switch(a.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}switch(a.key){case"h":case"0":a.preventDefault(),o(0);break;case"j":case"1":a.preventDefault(),o(1);break;case"k":case"2":a.preventDefault(),o(2);break;case"l":case"3":a.preventDefault(),o(3);break;case";":case"4":a.preventDefault(),o(4);break;case"'":case"5":a.preventDefault(),o(5);break}}Q(()=>{document.addEventListener("keydown",r),Z(()=>{document.removeEventListener("keydown",r)})});var i=no();Qt(i,20,()=>[1,2,3,4,5],Zt,(a,s)=>{var l=ro();ve(l),l.__click=()=>o(s),J(()=>{xt(l,"aria-label",`${s??""} star`),pe(l,t.rating===s)}),d(a,l)}),u(i),d(n,i),N()}C(["click"]);var ao=w('<button class="btn btn-sm btn-square hidden cursor-pointer items-center gap-x-2 md:flex"><!></button>');function Io(n,t){P(t,!1);const e=ae(fe());$t();var o=ao();o.__click=()=>se(e,h(e).isSidebarOpen=!h(e).isSidebarOpen);var r=v(o);ze(r,{size:18}),u(o),d(n,o),N()}C(["click"]);var so=w('<div class="md:tooltip md:tooltip-bottom z-30" data-tip="Previous"><button class="btn btn-square"><!></button></div> <div class="md:tooltip md:tooltip-bottom z-30" data-tip="Next"><button class="btn btn-square"><!></button></div>',1);function Do(n,t){P(t,!0);let e,o;function r(c){c&&(c.classList.add("bg-base-300"),setTimeout(()=>{c.classList.remove("bg-base-300")},100))}function i(c){switch(c.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}switch(c.key){case"ArrowLeft":case"a":c.preventDefault(),t.onLeft(),r(o);break;case"ArrowRight":case"d":case" ":c.preventDefault(),t.onRight(),r(e);break}}Q(()=>{document.addEventListener("keydown",i),Z(()=>{document.removeEventListener("keydown",i)})});var a=so(),s=f(a),l=v(s);l.__click=function(...c){var g;(g=t.onLeft)==null||g.apply(this,c)};var p=v(l);te(p,{size:18}),u(l),Pt(l,c=>o=c,()=>o),u(s);var _=L(s,2),y=v(_);y.__click=function(...c){var g;(g=t.onRight)==null||g.apply(this,c)};var k=v(y);Ee(k,{size:18}),u(y),Pt(y,c=>e=c,()=>e),u(_),J(()=>{l.disabled=t.currentIndex==0&&t.currentPage==1,y.disabled=t.currentIndex==t.lastItemIndex&&t.currentPage==t.totalPages}),d(n,a),N()}C(["click"]);var io=w('<div class="md:tooltip md:tooltip-bottom z-30" data-tip="See More"><button class="btn btn-square"><!></button></div> <div class="md:tooltip md:tooltip-bottom z-30" data-tip="See Less"><button class="btn btn-square"><!></button></div>',1);function zo(n,t){P(t,!0);let e,o;function r(c){c&&(c.classList.add("bg-base-300"),setTimeout(()=>{c.classList.remove("bg-base-300")},100))}function i(c){switch(c.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}switch(c.key){case"ArrowUp":case"w":c.preventDefault(),t.onUp(),r(e);break;case"ArrowDown":case"s":c.preventDefault(),t.onDown(),r(o);break}}Q(()=>{document.addEventListener("keydown",i),Z(()=>{document.removeEventListener("keydown",i)})});var a=io(),s=f(a),l=v(s);l.__click=function(...c){var g;(g=t.onUp)==null||g.apply(this,c)};var p=v(l);Ae(p,{size:18}),u(l),Pt(l,c=>e=c,()=>e),u(s);var _=L(s,2),y=v(_);y.__click=function(...c){var g;(g=t.onDown)==null||g.apply(this,c)};var k=v(y);Oe(k,{size:18}),u(y),Pt(y,c=>o=c,()=>o),u(_),d(n,a),N()}C(["click"]);var co=w('<div class="tooltip tooltip-bottom z-30" data-tip="Edit Note"><button class="btn btn-ghost flex items-center gap-x-2"><!></button></div>');function Ro(n,t){P(t,!0);let e=m(t,"isOpen",15);function o(s){switch(s.target.tagName){case"INPUT":case"TEXTAREA":case"BUTTON":case"DIV":case"TRIX-EDITOR":return}switch(s.key){case"e":s.preventDefault(),e(!0);break}}Q(()=>{document.addEventListener("keydown",o),Z(()=>{document.removeEventListener("keydown",o)})});var r=co(),i=v(r);i.__click=()=>e(!0);var a=v(i);xe(a,{size:18}),u(i),u(r),d(n,r),N()}C(["click"]);var lo=w('<div class="tooltip tooltip-bottom z-30" data-tip="Filter"><button class="btn btn-ghost flex items-center gap-x-2"><!></button></div>');function Mo(n,t){P(t,!0);let e=m(t,"isOpen",15);var o=lo(),r=v(o);r.__click=()=>e(!0);var i=v(r);Re(i,{size:18}),u(r),u(o),d(n,o),N()}C(["click"]);export{Io as T,To as a,ko as b,Eo as c,Ro as d,wo as e,Po as f,xo as g,Oo as h,Ao as i,No as j,Mo as k,Do as l,zo as m};
